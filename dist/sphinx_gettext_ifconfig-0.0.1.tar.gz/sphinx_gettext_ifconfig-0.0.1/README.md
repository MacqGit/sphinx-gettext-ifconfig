# sphinx-gettext
Enable to use .. ifconfig:: directives in translations
